import { useState, useEffect, useRef } from 'react';

// ============ NAVBAR COMPONENT ============
function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Menu', href: '#menu' },
    { name: 'Experience', href: '#experience' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-espresso/95 backdrop-blur-md shadow-lg py-3' : 'bg-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-2">
            <span className="text-3xl">☕</span>
            <span className="font-heading text-2xl font-bold text-cream">
              Barista <span className="text-caramel">Coffee</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-cream/80 hover:text-caramel font-medium transition-colors duration-300 text-sm uppercase tracking-wider"
              >
                {link.name}
              </a>
            ))}
            <a
              href="#menu"
              className="btn-primary bg-caramel text-espresso px-5 py-2 rounded-full font-semibold text-sm hover:bg-caramel-light transition-colors"
            >
              Order Now
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-cream p-2"
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden mt-4 pb-4 animate-slide-down">
            <div className="flex flex-col gap-3">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="text-cream/80 hover:text-caramel font-medium py-2 px-4 rounded-lg hover:bg-espresso-light/50 transition-all"
                >
                  {link.name}
                </a>
              ))}
              <a
                href="#menu"
                onClick={() => setIsOpen(false)}
                className="btn-primary bg-caramel text-espresso px-5 py-3 rounded-full font-semibold text-center mt-2"
              >
                Order Now
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

// ============ HERO SECTION ============
function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=1920&q=80')`,
        }}
      />
      {/* Overlay */}
      <div className="hero-overlay absolute inset-0" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 max-w-5xl mx-auto">
        <div className="animate-fade-in-up">
          <span className="inline-block text-caramel font-medium text-sm sm:text-base uppercase tracking-[0.3em] mb-4">
            ✦ Est. Addis Ababa, Ethiopia ✦
          </span>
        </div>

        <h1 className="font-heading text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-cream leading-tight mb-6 animate-fade-in-up delay-100">
          Your 24/7 Haven for{' '}
          <span className="text-caramel italic">Specialty Coffee</span>{' '}
          in Addis Ababa
        </h1>

        <p className="text-cream/80 text-lg sm:text-xl max-w-2xl mx-auto mb-10 animate-fade-in-up delay-200 font-light">
          Where expertly roasted Ethiopian beans meet a warm, inviting atmosphere — 
          any time of day or night.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up delay-300">
          <a
            href="#menu"
            className="btn-primary bg-caramel text-espresso px-8 py-4 rounded-full font-semibold text-lg hover:bg-caramel-light hover:scale-105 transition-all shadow-lg shadow-caramel/20"
          >
            View Our Menu
          </a>
          <a
            href="#contact"
            className="btn-primary border-2 border-cream/40 text-cream px-8 py-4 rounded-full font-semibold text-lg hover:bg-cream/10 hover:border-cream/80 hover:scale-105 transition-all"
          >
            Find Us / Visit Today
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-float">
          <div className="w-6 h-10 border-2 border-cream/40 rounded-full flex justify-center pt-2">
            <div className="w-1.5 h-3 bg-caramel rounded-full animate-bounce" />
          </div>
        </div>
      </div>
    </section>
  );
}

// ============ ABOUT SECTION ============
function AboutSection() {
  return (
    <section id="about" className="py-20 sm:py-28 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image Side */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&q=80"
                alt="Cozy coffee shop interior"
                className="w-full h-[400px] sm:h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-espresso/30 to-transparent" />
            </div>
            {/* Floating badge */}
            <div className="absolute -bottom-6 -right-4 sm:right-8 bg-espresso text-cream px-6 py-4 rounded-xl shadow-xl">
              <p className="font-heading text-3xl font-bold text-caramel">24/7</p>
              <p className="text-sm text-cream/80">Always Open</p>
            </div>
            {/* Decorative element */}
            <div className="absolute -top-4 -left-4 w-24 h-24 border-2 border-caramel/30 rounded-2xl -z-10" />
          </div>

          {/* Text Side */}
          <div>
            <span className="text-caramel font-medium text-sm uppercase tracking-[0.2em] mb-3 block">
              Our Story
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-espresso mb-6 leading-tight">
              More Than Just Coffee —{' '}
              <span className="text-caramel italic">A Community</span>
            </h2>
            <div className="space-y-5 text-charcoal-light text-lg leading-relaxed">
              <p>
                Born from a passion for Ethiopia's rich coffee heritage, Barista Coffee was founded 
                to create a space where the art of specialty coffee meets the warmth of community. 
                Nestled in the heart of Addis Ababa, we've become a beloved gathering place.
              </p>
              <p>
                Whether you're a remote worker seeking a productive haven, students diving into 
                late-night study sessions, friends catching up over artisanal brews, or coffee 
                aficionados exploring the nuances of single-origin Ethiopian beans — our doors 
                are always open.
              </p>
              <p>
                From the first sunrise pour-over to the midnight espresso, we believe great coffee 
                should be accessible at any hour. Our skilled baristas craft each cup with precision 
                and love, honoring the centuries-old traditions of Ethiopian coffee culture while 
                embracing modern specialty techniques.
              </p>
            </div>

            <div className="mt-8 flex flex-wrap gap-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-caramel/10 rounded-full flex items-center justify-center">
                  <span className="text-2xl">🌍</span>
                </div>
                <div>
                  <p className="font-semibold text-espresso">Ethiopian Heritage</p>
                  <p className="text-sm text-charcoal-light">Birthplace of Coffee</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-caramel/10 rounded-full flex items-center justify-center">
                  <span className="text-2xl">🏆</span>
                </div>
                <div>
                  <p className="font-semibold text-espresso">Award Winning</p>
                  <p className="text-sm text-charcoal-light">Specialty Roasts</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ============ MENU SECTION ============
function MenuSection() {
  const [activeTab, setActiveTab] = useState('espresso');

  const menuCategories = {
    espresso: {
      label: 'Signature Espresso',
      icon: '☕',
      items: [
        { name: 'Ethiopian Yirgacheffe Pour-Over', description: 'Bright, floral notes with hints of blueberry and citrus. Single-origin perfection.', price: '120 ETB' },
        { name: 'Barista Signature Latte', description: 'Velvety steamed milk with our house blend espresso, topped with artisanal latte art.', price: '95 ETB' },
        { name: 'Spiced Macchiato', description: 'Traditional macchiato infused with Ethiopian cardamom and a touch of honey.', price: '110 ETB' },
        { name: 'Double Shot Espresso', description: 'Bold, rich, and full-bodied. Our classic double shot from premium Arabica beans.', price: '70 ETB' },
        { name: 'Caramel Flat White', description: 'Smooth micro-foam milk layered over a double ristretto with house-made caramel.', price: '105 ETB' },
        { name: 'Mocha Harrar', description: 'Dark chocolate meets our signature espresso with steamed milk and whipped cream.', price: '115 ETB' },
      ]
    },
    traditional: {
      label: 'Traditional Ethiopian',
      icon: '🫖',
      items: [
        { name: 'Buna Ceremony (Full)', description: 'Experience the authentic Ethiopian coffee ceremony — roasted, ground, and brewed fresh before your eyes.', price: '200 ETB' },
        { name: 'Jebena Buna', description: 'Traditional clay pot brewed coffee with aromatic spices. Served with popcorn and incense.', price: '80 ETB' },
        { name: 'Spris (Three-Round Ceremony)', description: 'The complete Abol, Tona, and Baraka rounds of traditional Ethiopian coffee.', price: '150 ETB' },
        { name: 'Spiced Tea (Shai)', description: 'Aromatic Ethiopian spiced tea with cinnamon, cloves, and fresh ginger.', price: '50 ETB' },
      ]
    },
    pastries: {
      label: 'Pastries & Desserts',
      icon: '🥐',
      items: [
        { name: 'Himbasha (Ethiopian Bread)', description: 'Traditional slightly sweet celebration bread with cardamom and turmeric.', price: '60 ETB' },
        { name: 'Chocolate Croissant', description: 'Buttery, flaky layers filled with rich Belgian dark chocolate.', price: '85 ETB' },
        { name: 'Tiramisu Cup', description: 'Our barista\'s twist — espresso-soaked layers with mascarpone and cocoa.', price: '130 ETB' },
        { name: 'Almond Biscotti', description: 'Crunchy twice-baked Italian biscuits, perfect for dipping in your espresso.', price: '55 ETB' },
        { name: 'Cheesecake Slice', description: 'New York style creamy cheesecake with a buttery graham cracker crust.', price: '140 ETB' },
      ]
    },
    cold: {
      label: 'Cold Beverages',
      icon: '🧊',
      items: [
        { name: 'Cold Brew (12hr Steeped)', description: 'Smooth, low-acidity cold brew steeped for 12 hours. Served over ice.', price: '100 ETB' },
        { name: 'Iced Ethiopian Latte', description: 'Chilled espresso with cold milk over ice. Refreshing and energizing.', price: '110 ETB' },
        { name: 'Mango Smoothie', description: 'Fresh Ethiopian mangoes blended with yogurt and a hint of honey.', price: '90 ETB' },
        { name: 'Avocado Juice', description: 'Creamy fresh avocado blended with a touch of lime and honey.', price: '85 ETB' },
        { name: 'Iced Matcha Latte', description: 'Premium ceremonial grade matcha whisked with cold oat milk.', price: '120 ETB' },
      ]
    }
  };

  const tabs = Object.entries(menuCategories);
  const currentItems = menuCategories[activeTab as keyof typeof menuCategories].items;

  return (
    <section id="menu" className="py-20 sm:py-28 bg-cream-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="text-caramel font-medium text-sm uppercase tracking-[0.2em] mb-3 block">
            Our Menu
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-espresso mb-4">
            Crafted with <span className="text-caramel italic">Passion</span>
          </h2>
          <p className="text-charcoal-light text-lg max-w-2xl mx-auto">
            From traditional Ethiopian ceremonies to modern specialty drinks, 
            every cup tells a story of quality and craftsmanship.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-12">
          {tabs.map(([key, category]) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`px-4 sm:px-6 py-3 rounded-full font-medium text-sm sm:text-base transition-all duration-300 ${
                activeTab === key
                  ? 'bg-espresso text-cream shadow-lg shadow-espresso/20'
                  : 'bg-white text-charcoal hover:bg-espresso/5 border border-espresso/10'
              }`}
            >
              <span className="mr-2">{category.icon}</span>
              {category.label}
            </button>
          ))}
        </div>

        {/* Menu Items Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {currentItems.map((item, index) => (
            <div
              key={item.name}
              className="card-hover bg-white rounded-xl p-6 border border-espresso/5 shadow-sm"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex justify-between items-start mb-3">
                <h3 className="font-heading text-xl font-semibold text-espresso pr-4">
                  {item.name}
                </h3>
                <span className="text-caramel font-bold text-lg whitespace-nowrap">
                  {item.price}
                </span>
              </div>
              <p className="text-charcoal-light text-sm leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ============ EXPERIENCE SECTION ============
function ExperienceSection() {
  const features = [
    {
      icon: '🕐',
      title: 'Open 24/7',
      description: 'Always open when you need a brew, a meal, or a quiet workspace. Day or night, we\'re here for you.',
    },
    {
      icon: '📶',
      title: 'High-Speed Wi-Fi',
      description: 'Reliable, fast internet with plenty of power outlets. The perfect remote work or study environment.',
    },
    {
      icon: '🪑',
      title: 'Cozy Seating',
      description: 'From intimate corners to communal tables — find your perfect spot to work, relax, or socialize.',
    },
    {
      icon: '🫘',
      title: 'Expertly Roasted Beans',
      description: 'We source and roast the finest Ethiopian beans. Every cup is crafted by skilled, passionate baristas.',
    },
    {
      icon: '🎵',
      title: 'Curated Atmosphere',
      description: 'Thoughtfully selected music and warm lighting create the perfect ambiance for any mood or occasion.',
    },
    {
      icon: '🌱',
      title: 'Sustainable Practices',
      description: 'Ethically sourced beans, eco-friendly packaging, and a commitment to our local community.',
    },
  ];

  return (
    <section id="experience" className="py-20 sm:py-28 bg-espresso text-cream relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="text-caramel font-medium text-sm uppercase tracking-[0.2em] mb-3 block">
            Why Choose Us
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            The Barista <span className="text-caramel italic">Experience</span>
          </h2>
          <p className="text-cream/70 text-lg max-w-2xl mx-auto">
            More than a coffee shop — we're your second home, your office, your sanctuary.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="card-hover bg-espresso-light/30 backdrop-blur-sm rounded-xl p-8 border border-cream/10 hover:border-caramel/30 group"
            >
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                {feature.icon}
              </div>
              <h3 className="font-heading text-xl font-semibold mb-3 text-cream group-hover:text-caramel transition-colors">
                {feature.title}
              </h3>
              <p className="text-cream/60 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ============ REVIEWS SECTION ============
function ReviewsSection() {
  const reviews = [
    {
      name: 'Abebe T.',
      role: 'Remote Developer',
      quote: 'Barista Coffee is my daily office. The Wi-Fi is reliable, the coffee is exceptional, and the 24/7 hours mean I can work whenever inspiration strikes. Best workspace in Addis!',
      rating: 5,
    },
    {
      name: 'Sara M.',
      role: 'Graduate Student',
      quote: 'As a student, having a place that\'s open late and serves amazing coffee is a lifesaver. The traditional Ethiopian ceremony here is absolutely authentic and beautiful.',
      rating: 5,
    },
    {
      name: 'Daniel K.',
      role: 'Coffee Enthusiast',
      quote: 'The single-origin Yirgacheffe pour-over here is the best I\'ve had outside of the farm itself. These guys truly understand specialty coffee. A must-visit for any coffee lover.',
      rating: 4,
    },
    {
      name: 'Meron A.',
      role: 'Freelance Designer',
      quote: 'The atmosphere is unmatched — warm, creative, and inspiring. I\'ve completed entire projects here. Plus, the pastries are absolutely divine!',
      rating: 5,
    },
  ];

  return (
    <section id="reviews" className="py-20 sm:py-28 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="text-caramel font-medium text-sm uppercase tracking-[0.2em] mb-3 block">
            Testimonials
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-espresso mb-4">
            Loved by Our <span className="text-caramel italic">Community</span>
          </h2>
        </div>

        {/* Rating Badge */}
        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-2xl shadow-xl px-8 py-6 flex items-center gap-6 border border-espresso/5">
            <div className="text-center">
              <p className="font-heading text-5xl font-bold text-espresso">4.3</p>
              <div className="flex gap-1 mt-2 justify-center">
                {[1, 2, 3, 4].map((star) => (
                  <span key={star} className="text-caramel text-lg">★</span>
                ))}
                <span className="text-caramel/40 text-lg">★</span>
              </div>
              <p className="text-sm text-charcoal-light mt-1">Community Rating</p>
            </div>
            <div className="w-px h-16 bg-espresso/10" />
            <div className="text-center">
              <p className="font-heading text-5xl font-bold text-espresso">500+</p>
              <p className="text-sm text-charcoal-light mt-2">Happy Reviews</p>
            </div>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {reviews.map((review, index) => (
            <div
              key={review.name}
              className="card-hover bg-white rounded-xl p-8 border border-espresso/5 shadow-sm"
            >
              <div className="flex gap-1 mb-4">
                {Array.from({ length: review.rating }).map((_, i) => (
                  <span key={i} className="text-caramel">★</span>
                ))}
                {Array.from({ length: 5 - review.rating }).map((_, i) => (
                  <span key={i} className="text-caramel/30">★</span>
                ))}
              </div>
              <p className="text-charcoal-light leading-relaxed mb-6 italic">
                "{review.quote}"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-caramel/10 rounded-full flex items-center justify-center">
                  <span className="text-espresso font-semibold text-sm">
                    {review.name.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-espresso">{review.name}</p>
                  <p className="text-sm text-charcoal-light">{review.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ============ CONTACT / FOOTER SECTION ============
function ContactSection() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <section id="contact" className="bg-espresso text-cream">
      {/* Map / Location Area */}
      <div className="relative">
        <div className="h-64 sm:h-80 bg-espresso-light/50 relative overflow-hidden">
          {/* Map placeholder with styled background */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="w-20 h-20 bg-caramel/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-float">
                <span className="text-4xl">📍</span>
              </div>
              <h3 className="font-heading text-2xl font-bold text-cream mb-2">Find Us in Addis Ababa</h3>
              <p className="text-cream/70">Bole Road, Near Edna Mall, Addis Ababa, Ethiopia</p>
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block mt-4 text-caramel hover:text-caramel-light font-medium transition-colors"
              >
                Open in Google Maps →
              </a>
            </div>
          </div>
          {/* Decorative grid pattern */}
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: 'linear-gradient(rgba(200,150,62,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(200,150,62,0.3) 1px, transparent 1px)',
            backgroundSize: '50px 50px'
          }} />
        </div>
      </div>

      {/* Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <span className="text-3xl">☕</span>
              <span className="font-heading text-2xl font-bold text-cream">
                Barista <span className="text-caramel">Coffee</span>
              </span>
            </div>
            <p className="text-cream/60 leading-relaxed mb-6">
              Your 24/7 specialty coffee destination in the heart of Addis Ababa. 
              Where every cup tells a story.
            </p>
            {/* Social Links */}
            <div className="flex gap-4">
              {['facebook', 'instagram', 'twitter', 'tiktok'].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="w-10 h-10 bg-cream/10 rounded-full flex items-center justify-center hover:bg-caramel/20 hover:text-caramel transition-all"
                  aria-label={social}
                >
                  <span className="text-sm capitalize">{social.charAt(0).toUpperCase()}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading text-lg font-semibold mb-4 text-cream">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'About Us', 'Menu', 'Experience', 'Reviews'].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(' ', '')}`} className="text-cream/60 hover:text-caramel transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Hours & Contact */}
          <div>
            <h4 className="font-heading text-lg font-semibold mb-4 text-cream">Hours & Contact</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <span className="text-caramel mt-1">🕐</span>
                <div>
                  <p className="font-semibold text-cream">Open 24 Hours</p>
                  <p className="text-cream/60 text-sm">7 Days a Week, 365 Days</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-caramel mt-1">📞</span>
                <div>
                  <p className="text-cream/60">+251 911 234 567</p>
                  <p className="text-cream/60">+251 911 234 568</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-caramel mt-1">✉️</span>
                <p className="text-cream/60">hello@baristacoffee.et</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-caramel mt-1">📍</span>
                <p className="text-cream/60">Bole Road, Near Edna Mall<br />Addis Ababa, Ethiopia</p>
              </div>
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-heading text-lg font-semibold mb-4 text-cream">Stay Updated</h4>
            <p className="text-cream/60 mb-4 text-sm">
              Subscribe to our newsletter for exclusive offers, new menu items, and events.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className="w-full px-4 py-3 bg-cream/10 border border-cream/20 rounded-lg text-cream placeholder:text-cream/40 focus:outline-none focus:border-caramel transition-colors"
                required
              />
              <button
                type="submit"
                className="btn-primary w-full bg-caramel text-espresso px-6 py-3 rounded-lg font-semibold hover:bg-caramel-light transition-colors"
              >
                {subscribed ? '✓ Subscribed!' : 'Subscribe'}
              </button>
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-cream/10 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-cream/40 text-sm">
            © 2024 Barista Coffee. All rights reserved. Made with ☕ in Addis Ababa.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-cream/40 hover:text-caramel text-sm transition-colors">Privacy Policy</a>
            <a href="#" className="text-cream/40 hover:text-caramel text-sm transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </section>
  );
}

// ============ MAIN APP ============
export default function App() {
  return (
    <div className="min-h-screen bg-cream">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <MenuSection />
      <ExperienceSection />
      <ReviewsSection />
      <ContactSection />
    </div>
  );
}
